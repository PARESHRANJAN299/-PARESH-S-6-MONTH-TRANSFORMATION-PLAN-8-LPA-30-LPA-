﻿📘 Day-1 Practice Questions (SELECT Fundamentals)

Display all records from the device_events table.
Select * from device_events;
Show only device_id and event_type for all device events.

select device_id, event_type
from device_events;
List all events that belong to device DEV1001.
select * from 
device_events
where device_id = 'DEV1001';
Find all events where the event_type is SIM_CHANGE.
select * from 
device_events
where event_type = 'SIM_CHANGE';
Display device_id and event_time for all factory reset events.
select device_id, event_time
from device_events
where is_factory_reset = 1;

Show all events that occurred on or after 20 January 2025.
select * from device_events
where event_time > '2025-01-20';
Retrieve events where the network_type is 5G.
select * from device_events
where network_type = '5G' ;
List devices where the battery_level is less than 20.
select * from device_events
where battery_level <20;
Display all events that occurred in the city Bhubaneswar.

select * from device_events
where location_city = 'Bhubaneswar';
Show device_id, event_type, and event_time using a table alias for the device_events table.
select device_id, event_type, event_time as the_device_events_table
from device_events
